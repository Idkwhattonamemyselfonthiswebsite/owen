# Volleyball Legends Online (1v1)

A small browser-based 1v1 volleyball game with private room codes. The Node.js server hosts the page and synchronizes player positions, ball physics, and scoring over WebSockets.

## Run locally

1. Install Node.js 18 or newer.
2. In this folder, run `npm install`.
3. Run `npm start`.
4. Open `http://localhost:3000` in two browser tabs to test. Create a room in one tab and join with its code in the other.

## Put it online for Chromebook play

Deploy this folder as a Node web service on a hosting provider that supports persistent WebSocket connections (for example, Render):

1. Put the project in a GitHub repository.
2. Create a new **Web Service** from that repository.
3. Set the build command to `npm install`.
4. Set the start command to `npm start`.
5. Use the public HTTPS URL from the host. Both players open the same URL in Chrome, one creates a room, and the other enters the room code.

Do not deploy as a static-only site. The Node server must stay running because it handles the WebSocket rooms and real-time game state. Hosting providers may require an account and may have usage limits or paid plans.

## Controls

- A / D or Left / Right: move
- W / Up: jump
- Q: pass
- E: set
- R: spike
- Space: serve

This is an early playable prototype. It has simple arcade physics and basic ball contact, not a full professional volleyball simulation.
