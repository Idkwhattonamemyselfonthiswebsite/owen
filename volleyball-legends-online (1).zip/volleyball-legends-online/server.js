const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const WebSocket = require('ws');
const PORT = process.env.PORT || 3000;
const ROOT = path.join(__dirname, 'public');
const rooms = new Map();
const MIME = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.ico':'image/x-icon'};
const server = http.createServer((req,res)=>{
  let pathname = decodeURIComponent((req.url || '/').split('?')[0]);
  if (pathname === '/') pathname = '/index.html';
  const file = path.join(ROOT, pathname.replace(/^\/+/,''));
  if (!file.startsWith(ROOT)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file,(err,data)=>{
    if(err){res.writeHead(404);return res.end('Not found');}
    res.writeHead(200,{'Content-Type':MIME[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store'});res.end(data);
  });
});
const wss = new WebSocket.Server({server});
function send(ws,obj){if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(obj));}
function broadcast(room,obj){room.players.forEach(p=>send(p.ws,obj));}
function newGame(){return {score:[0,0],ball:{x:450,y:330,vx:0,vy:0},players:[{x:180,y:0,vy:0},{x:720,y:0,vy:0}],phase:'serve',serveBy:0,lastTouch:-1,pointAt:0};}
function snapshot(room){return {type:'state',room:room.code,players:room.players.map((p,i)=>({name:p.name,side:i})),game:room.game};}
function roomCode(){return crypto.randomBytes(3).toString('hex').toUpperCase();}
wss.on('connection',ws=>{
  ws.on('message',raw=>{
    let msg;try{msg=JSON.parse(raw.toString())}catch{return;}
    if(msg.type==='create'){
      let code=roomCode();while(rooms.has(code))code=roomCode();
      const room={code,players:[{ws,name:String(msg.name||'Player 1').slice(0,16),input:{} }],game:newGame()};rooms.set(code,room);ws.room=code;ws.side=0;
      send(ws,{type:'joined',room:code,side:0,waiting:true});return;
    }
    if(msg.type==='join'){
      const code=String(msg.room||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,8);const room=rooms.get(code);
      if(!room){send(ws,{type:'error',message:'Room not found. Check the code and try again.'});return;}
      if(room.players.length>=2){send(ws,{type:'error',message:'This room already has two players.'});return;}
      room.players.push({ws,name:String(msg.name||'Player 2').slice(0,16),input:{}});ws.room=code;ws.side=1;
      send(ws,{type:'joined',room:code,side:1,waiting:false});broadcast(room,{type:'ready',players:room.players.map(p=>p.name)});broadcast(room,snapshot(room));return;
    }
    const room=rooms.get(ws.room);if(!room)return;
    if(msg.type==='input'){
      const p=room.players[ws.side];if(p)p.input={left:!!msg.left,right:!!msg.right,jump:!!msg.jump,action:['pass','set','spike','serve'].includes(msg.action)?msg.action:null};
    }
    if(msg.type==='rematch'&&room.players.length===2){room.game=newGame();broadcast(room,snapshot(room));}
  });
  ws.on('close',()=>{const room=rooms.get(ws.room);if(!room)return;room.players=room.players.filter(p=>p.ws!==ws);broadcast(room,{type:'opponentLeft'});if(!room.players.length)rooms.delete(room.code);});
});
const W=900,G=430,NET=450;
function point(room,winner){const g=room.game;if(g.phase!=='rally')return;g.score[winner]++;g.phase='point';g.pointAt=Date.now();g.serveBy=winner;if(g.score[winner]>=15&&g.score[winner]-g.score[1-winner]>=2)g.phase='over';}
function resetRally(g){g.players=[{x:180,y:0,vy:0},{x:720,y:0,vy:0}];g.ball={x:g.serveBy===0?180:720,y:350,vx:0,vy:0};g.phase='serve';g.lastTouch=-1;}
function step(room){if(room.players.length!==2)return;const g=room.game;
 if(g.phase==='point'&&Date.now()-g.pointAt>1700)resetRally(g);
 if(g.phase==='over')return;
 g.players.forEach((p,i)=>{const input=room.players[i].input||{};const dir=(input.right?1:0)-(input.left?1:0);p.x=Math.max(i===0?25:NET+35,Math.min(i===0?NET-35:875,p.x+dir*5));p.y=Math.min(0,p.y+p.vy);p.vy=Math.min(0,p.vy+0.65);if(input.jump&&p.y===0)p.vy=-12;});
 if(g.phase==='serve'){
  const inp=room.players[g.serveBy].input||{};
  if(inp.action==='serve'){g.phase='rally';g.ball={x:g.players[g.serveBy].x,y:330,vx:g.serveBy===0?8:-8,vy:-10};g.lastTouch=g.serveBy;room.players[g.serveBy].input.action=null;}
  return;
 }
 if(g.phase!=='rally')return;
 const b=g.ball;b.vy+=0.32;b.x+=b.vx;b.y+=b.vy;
 if(b.x<0||b.x>W){point(room,b.x<0?1:0);return;}
 if(b.y<10){b.y=10;b.vy=Math.abs(b.vy)*.65;}
 if(Math.abs(b.x-NET)<9&&b.y>235){b.vx*=-.55;b.x+=b.x<NET?-10:10;}
 if(b.y>=G){point(room,b.x<NET?1:0);return;}
 for(let i=0;i<2;i++){
  const p=g.players[i],input=room.players[i].input||{};const near=Math.hypot(b.x-p.x,b.y-(G-30+p.y))<72;
  if(near&&input.action&&['pass','set','spike'].includes(input.action)){
   const a=input.action,dir=i===0?1:-1;
   if(a==='pass'){b.vx=dir*4.5;b.vy=-9;}
   if(a==='set'){b.vx=dir*5.5;b.vy=-12;}
   if(a==='spike'){b.vx=dir*11;b.vy=-5;}
   g.lastTouch=i;input.action=null;
  }
 }
}
setInterval(()=>{for(const room of rooms.values()){step(room);broadcast(room,snapshot(room));}},1000/30);
server.listen(PORT,()=>console.log(`Volleyball Legends listening on ${PORT}`));
